/*
ID: 20200178
NAME: Taeil Kim
assignment3
FILE NAME: customer_manager1.c
*/

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "customer_manager.h"

/*----------------------------------------------------------------------*/

#define UNIT_ARRAY_SIZE 1024
enum { HASH_MULTIPLIER = 65599 };            

struct UserInfo {
    char* name;                // customer name
    char* id;                  // customer id
    int purchase;              // purchase amount (> 0)
    struct UserInfo* nextId;   // next user id information
    struct UserInfo* nextName; // next user name information
};

struct Table {
    struct UserInfo* array[UNIT_ARRAY_SIZE]; // hash table
};

struct DB {
    struct Table* idTable;    // hash table for id
    struct Table* nameTable;  // hash table for name
    int iBucketCount;         // current array size (max # of elements)
    int numItems;             // # of stored items, needed to determine
                              // # whether the array should be expanded
                              // # or not
};

static int hash_function(const char* pcKey, int iBucketCount)

/* Return a hash code for pcKey that is between 0 and iBucketCount-1,
   inclusive. Adapted from the EE209 lecture notes. */
{
    int i;
    unsigned int uiHash = 0U;
    for (i = 0; pcKey[i] != '\0'; i++)
        uiHash = uiHash * (unsigned int)HASH_MULTIPLIER
        + (unsigned int)pcKey[i];
    return (int)(uiHash % (unsigned int)iBucketCount);
}
/*--------------------------------------------------------------------*/
DB_T
CreateCustomerDB(void)
{
    /*
     This function allocate memory for a new DB_T which is d.
     if success, it returns d.
     if fail, it returns NULL.
    */

    DB_T d;

    d = (DB_T)malloc(sizeof(struct DB));
    if (d == NULL) {
        fprintf(stderr, "Can't allocate a memory for DB_T\n");
        return NULL;
    }
    d->iBucketCount= UNIT_ARRAY_SIZE; // start with 1024 elements
    d->numItems = 0;
    // allocate memory for two hash table
    d->idTable = (struct Table *)calloc(1, sizeof(struct Table));
    d->nameTable = (struct Table*)calloc(1, sizeof(struct Table));
    if (d->idTable == NULL || d->nameTable == NULL) {
        fprintf(stderr, "Can't allocate a memory for array of size %d\n"
            , d->iBucketCount);
        free(d);
        return NULL;
    }
    return d;
}
/*--------------------------------------------------------------------*/
void
DestroyCustomerDB(DB_T d)
{
    /*
     This function frees all memory by the parameter d
     It returns nothing.
    */

    // free all the memory which is used for customerDB
    if (d == NULL) return;//If input d is NULL, it should do nothing.
    struct UserInfo* p;
    struct UserInfo* nextp;
    for (int i = 0; i < d->iBucketCount; i++) {
        for (p = d->idTable->array[i]; p != NULL; p = nextp) {
            nextp = p->nextId;
            free(p->id);
            free(p->name);
            free(p);
        }
    }
    free(d->idTable);
    free(d->nameTable);
    free(d);
    return;
}
/*--------------------------------------------------------------------*/
int
RegisterCustomer(DB_T d, const char* id,
    const char* name, const int purchase)
{
    /*
     This function register new user information
     by the parameters id, name, purchase.
     if success, it returns 0,
     if fail, it returns -1.
    */

    struct Table* t1; //new pointer to idTable for realloc
    struct Table* t2; //new pointer to nameTable for realloc

    //If any of d, id, or name is NULL, it is a failure.
    if (d == NULL || id == NULL || name == NULL)
        return -1;
    //If purchase is zero or a negative number, it is a failure.
    if (purchase <= 0)
        return -1;

    //If 75% full, double the length of the hash table
    if (d->numItems == (0.75)*(d->iBucketCount) && d->iBucketCount 
        < 1048576) {
        d->iBucketCount *= 2;
        t1 = (struct Table*)realloc(d->idTable, d->iBucketCount 
            * sizeof(struct UserInfo*));
        t2 = (struct Table*)realloc(d->nameTable, d->iBucketCount 
            * sizeof(struct UserInfo*));
        //When there is not enough memory
        if (t1 == NULL) {
            fprintf(stderr, "Can't expand memory for array of size %d\n"
                , d->iBucketCount);
            free(d->idTable);
            return -1;
        }
        if (t2 == NULL) {
            fprintf(stderr, "Can't expand memory for array of size %d\n"
                , d->iBucketCount);
            free(d->nameTable);
            return -1;
        }
        //When memory is  allocated in another place
        if (d->idTable != t1)
            d->idTable = t1;
        if (d->nameTable != t2)
            d->nameTable = t2;
    }

    struct UserInfo* p = (struct UserInfo*)calloc(1, 
        sizeof(struct UserInfo));
    //prepare hash key for id to go to the index of hash table
    int hashId = hash_function(id, d->iBucketCount);
    int hashName = hash_function(name, d->iBucketCount);

    //If an item with the same id or with the same name already exists,
    //it is a failure.
    for (struct UserInfo* q = d->idTable->array[hashId]; q != NULL;
        q = q->nextId) {
        if (strcmp(q->id, id) == 0) 
            return -1;
    }
    for (struct UserInfo* q = d->nameTable->array[hashName]; q != NULL;
        q = q->nextName) {
        if (strcmp(q->name, name) == 0)
            return -1;
    }
    //Write user information in the hash table 
    //and own the id and name strings
    p->id = strdup(id);
    p->name = strdup(name);
    p->purchase = purchase;
    
    p->nextId = d->idTable->array[hashId];
    p->nextName = d->nameTable->array[hashName];
    d->idTable->array[hashId] = p;
    d->nameTable->array[hashName] = p;
    d->numItems++;
    return 0;
}
/*--------------------------------------------------------------------*/
int
UnregisterCustomerByID(DB_T d, const char* id)
{
    /*
     This function unregister user information
     by the parameter d, id.
     it frees all the memoey occupied by a user which is id and name.
     if success, it returns 0,
     if fail, it returns -1.
    */

    //If d or id is NULL, it is a failure.
    if (d == NULL || id == NULL)
        return -1;
    
    //check whether given id is in the linked list
    int isInList = 0;   
    //the number of nodes in linked list of the id hash table
    int linkedId = 0;
    //prepare hash key for id to go to the index of hash table
    int hashId = hash_function(id, d->iBucketCount);
    struct UserInfo* p1;

    //In linked list of given hash key for id, find the id
    for (p1 = d->idTable->array[hashId]; p1 != NULL
        ; p1 = p1->nextId) {
        linkedId++;
        if (strcmp(p1->id, id) == 0) {
            isInList = 1;
            //if id is a first node 
            if (linkedId == 1)
                d->idTable->array[hashId] = p1->nextId;
            //if id is not a first node
            else
                p1 = p1->nextId;
            break;
        }
    }
    //If no such item exists, it is a failure.
    if (isInList == 0)
        return -1;

    //the number of nodes in linked list of the name hash table
    int linkedName = 0; 
    //prepare hash key for name to go to the index of hash table
    int hashName = hash_function(p1->name, d->iBucketCount);
    
    //In linked list of given hash key for name, find the name
    for (struct UserInfo* p2 = d->nameTable->array[hashName]; p2 != NULL;
        p2 = p2->nextName) {
        linkedName++;
        if (strcmp(p2->name, p1->name) == 0) {
            isInList = 1;
            //if name is a first node
            if (linkedName == 1)
                d->nameTable->array[hashName] = p2->nextName;
            //if name is not a first node
            else
                p2 = p2->nextName;
            break;
        }
    }

    //free the owned id and name string
    free(p1->id);
    free(p1->name);
    free(p1);
    d->numItems--;
    return 0;
}

/*--------------------------------------------------------------------*/
int
UnregisterCustomerByName(DB_T d, const char* name)
{
    /*
     This function unregister user information
     by the parameter d, name.
     it frees all the memoey occupied by a user which is id and name.
     if success, it returns 0,
     if fail, it returns -1.
    */

    //If d or id is NULL, it is a failure.
    if (d == NULL || name == NULL)
        return -1;

    //check whether given id is in the linked list
    int isInList = 0;  
    //the number of nodes in linked list of the name hash table
    int linkedName = 0; 
    //prepare hash key for name to go to the index of hash table
    int hashName = hash_function(name, d->iBucketCount);
    struct UserInfo* p1;
 
    //In linked list of given hash key for name, find the name
    for (p1 = d->nameTable->array[hashName]; p1 != NULL; 
        p1 = p1->nextName) {
        linkedName++;
        if (strcmp(p1->name, name) == 0) {
            isInList = 1;
            //if name is a first node
            if (linkedName == 1)
                d->nameTable->array[hashName] = p1->nextName;
            //if name is not a first node
            else
                p1 = p1->nextName;
            break;
        }
    }
    //If no such item exists, it is a failure.
    if (isInList == 0)
        return -1;

    //the number of nodes in linked list of the id hash table
    int linkedId = 0; 
    //prepare hash key for id to go to the index of hash table
    int hashId = hash_function(p1->id, d->iBucketCount);
    
    //In linked list of given hash key for id, find the id
    for (struct UserInfo* p2 = d->idTable->array[hashId]; p2 != NULL;
        p2 = p2->nextId) {
        linkedId++; 
        if (strcmp(p2->id, p1->id) == 0) {
            //if id is a first node
            if (linkedId == 1)
                d->idTable->array[hashId] = p2->nextId;
            //if id is not a first node
            else
                p2 = p2->nextId;
            break;
        }
    }

    //free the owned id and name string
    free(p1->id);
    free(p1->name);
    free(p1);
    d->numItems--;
    return 0;
}
/*--------------------------------------------------------------------*/
int
GetPurchaseByID(DB_T d, const char* id)
{
    /*
     This function get purchase value by the parameter d, id.
     it returns the purchase value.
     if fail, returns -1.
     */

    //If d or id is NULL, it is a failure.
    if (d == NULL || id == NULL)
        return -1;

    //prepare hash key for id to go to the index of hash table
    int hashId = hash_function(id, d->iBucketCount);

    //if same id is found, return the purchase
    for (struct UserInfo* p = d->idTable->array[hashId];
        p != NULL; p = p->nextId) {
        if (strcmp(p->id, id) == 0)
            return p->purchase;
    }
    return -1;//If there is no same id, it is a failure.
}
/*--------------------------------------------------------------------*/
int
GetPurchaseByName(DB_T d, const char* name)
{
    /* 
     This function get purchase value by the parameter d, name.
     it returns the purchase value.
     if fail, returns -1.
     */

    //If d or name is NULL, it is a failure.
    if (d == NULL || name == NULL)
        return -1;

    //prepare hash key for name to go to the index of hash table
    int hashName = hash_function(name, d->iBucketCount);

    //if same name is found, return the purchase
    for (struct UserInfo* p = d->nameTable->array[hashName]; 
        p != NULL; p = p->nextName) {
        if (strcmp(p->name, name) == 0)
            return p->purchase;
    }
    return -1;//If there is no same name, it is a failure.
}
/*--------------------------------------------------------------------*/
int
GetSumCustomerPurchase(DB_T d, FUNCPTR_T fp)
{
    /*
     This function calculates the sum of all of purchase values
     by the parameter d, fp.
     it returns sum value.
     if fail, it returns -1.
    */
     
    int sum = 0;

    //If d or fp is NULL, it should return -1.
    if (d == NULL || fp == NULL)
        return -1;

    //calculate sum of the numbers 
    //returned by fp by calling fp for each user item. 
    for (int i = 0; i < d->iBucketCount; i++) {
        for (struct UserInfo* p = d->idTable->array[i];
            p != NULL; p = p->nextId) {
            sum += fp(p->id, p->name, p->purchase);
        }
    }
    return sum;
}