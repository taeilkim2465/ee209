/*
ID: 20200178
NAME: Taeil Kim
assignment3
FILE NAME: customer_manager1.c
*/

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "customer_manager.h"

/*----------------------------------------------------------------------*/
//Uncomment and use the following code if you want

#define UNIT_ARRAY_SIZE 64

struct UserInfo {
    char* name;                // customer name
    char* id;                  // customer id
    int purchase;              // purchase amount (> 0) 
};

struct DB {
    struct UserInfo *pArray;   // pointer to the array
    int curArrSize;            // current array size (max # of elements)
    int numItems;              // # of stored items, needed to determine
			     // # whether the array should be expanded
			     // # or not
};

/*--------------------------------------------------------------------*/
DB_T
CreateCustomerDB(void)
{
    /*
     This function allocate memory for a new DB_T which is d.
     if success, it returns d.
     if fail, it returns NULL.
    */

    DB_T d;

    d = (DB_T) calloc(1, sizeof(struct DB)); 
    if (d == NULL) {
        fprintf(stderr, "Can't allocate a memory for DB_T\n");
        return NULL;
    }
    d->curArrSize = UNIT_ARRAY_SIZE; // start with 64 elements
    d->pArray = (struct UserInfo *)calloc(d->curArrSize,
        sizeof(struct UserInfo));
    d->numItems = 0;
    if (d->pArray == NULL) {
        fprintf(stderr, "Can't allocate a memory for array of size %d\n"
            , d->curArrSize);
        free(d);
        return NULL;
    }
    return d;
}
/*--------------------------------------------------------------------*/
void
DestroyCustomerDB(DB_T d)
{
    /*
     This function frees all memory by the parameter d
     It returns nothing.
    */

    if (d == NULL) return; //If input d is NULL, it should do nothing.
    for (int i = 0; i < d->numItems; i++) {
        free(d->pArray[i].id);
        free(d->pArray[i].name);
        d->pArray[i].purchase = 0;
    }
    free(d->pArray);
    free(d);
    return;
}
/*--------------------------------------------------------------------*/
int
RegisterCustomer(DB_T d, const char *id,
		 const char *name, const int purchase)
{
    /*
     This function register new user information 
     by the parameters id, name, purchase.
     if success, it returns 0,
     if fail, it returns -1.
    */

    //new pointer to userinfo array for realloc
    struct UserInfo* pArray1; 

    //If any of d, id, or name is NULL, it is a failure.
    if (d == NULL || id == NULL || name == NULL)
        return -1;
    //If purchase is zero or a negative number, it is a failure.
    if (purchase <= 0)
        return -1;

    //If there is no empty element in a array, 
    //add 64 elements to the array
    if(d->curArrSize == d->numItems){
        d->curArrSize += UNIT_ARRAY_SIZE;
        pArray1 = (struct UserInfo*)realloc(d->pArray, d->curArrSize 
            * sizeof(struct UserInfo));
        //When there is not enough memory
        if (pArray1 == NULL) {
            fprintf(stderr, "Can't expand memory for array of size %d\n"
                , d->curArrSize);
            free(d->pArray);
            return -1;
        }
        //When memory is  allocated in another place
        if (d->pArray != pArray1)
            d->pArray = pArray1;
    }

    //If an item with the same id or with the same name already exists,
    //it is a failure.
    for (int i = 0; i < d->numItems; i++) {
        if (strcmp(d->pArray[i].id, id) == 0)
            return -1;
        if (strcmp(d->pArray[i].name, name) == 0)
            return -1;
    }

    //Write user information in the array 
    //and own the id and name strings
    d->pArray[d->numItems].name = strdup(name);
    d->pArray[d->numItems].id = strdup(id);
    d->pArray[d->numItems].purchase = purchase;
    d->numItems++;
    return 0;
}
/*--------------------------------------------------------------------*/
int
UnregisterCustomerByID(DB_T d, const char *id)
{
    /* 
     This function unregister user information 
     by the parameter d, id.
     it frees all the memoey occupied by a user which is id and name.
     if success, it returns 0,  
     if fail, it returns -1.
    */

    //If d or id is NULL, it is a failure.
    if (d == NULL || id == NULL)
        return -1;

    //If the same id is found in the array, 
    //the owned id and name string are freed.
    for (int i = 0; i < d->numItems; i++) {
        if (strcmp(d->pArray[i].id, id) == 0) {
            free(d->pArray[i].id);
            free(d->pArray[i].name);
            d->pArray[i].purchase = 0;
            d->numItems--;
            return 0;
        }
    }

    return -1;//If no such item exists, it is a failure.
}

/*--------------------------------------------------------------------*/
int
UnregisterCustomerByName(DB_T d, const char *name)
{
    /* 
     This function unregister user information 
     by the parameter d, name.
     it frees all the memoey occupied by a user which is id and name.
     if success, it returns 0,
     if fail, it returns -1.
    */

    //If d or name is NULL, it is a failure.
    if (d == NULL || name == NULL)
        return -1;

    //If the same name is found in the array,
    //the owned id and name string are freed.
    for (int i = 0; i < d->numItems; i++) {
        if (strcmp((d->pArray + i)->name, name) == 0) {
            free(d->pArray[i].id);
            free(d->pArray[i].name);
            d->pArray[i].purchase = 0;
            d->numItems--;
            return 0;
        }
    }

    return -1;//If no such item exists, it is a failure.
}
/*--------------------------------------------------------------------*/
int
GetPurchaseByID(DB_T d, const char* id)
{
    /* 
     This function get purchase value by the parameter d, id.
     it returns the purchase value.
     if fail, returns -1. 
     */

    //If d or id is NULL, it is a failure.
    if (d == NULL || id == NULL)
        return -1;

    //if same id is found, return the purchase
    for (int i = 0; i < d->numItems; i++) {
        if (strcmp(d->pArray[i].id, id) == 0) {
            return d->pArray[i].purchase;
        }
    }
    return -1;//If there is no same id in the array, it is a failure.
}
/*--------------------------------------------------------------------*/
int
GetPurchaseByName(DB_T d, const char* name)
{
    /* 
     This function get purchase value by the parameter d, name.
     it returns the purchase value.
     if fail, returns -1.
     */

    //If d or name is NULL, it is a failure.
    if (d == NULL || name == NULL)
        return -1;

    //if same name is found, return the purchase
    for (int i = 0; i < d->numItems; i++) {
        if (strcmp(d->pArray[i].name, name) == 0) {
            return d->pArray[i].purchase;
        }
    }
    return -1;//If there is no same name in the array, it is a failure.
}
/*--------------------------------------------------------------------*/
int
GetSumCustomerPurchase(DB_T d, FUNCPTR_T fp)
{
    /*
     This function calculates the sum of all of purchase values 
     by the parameter d, fp.
     it returns sum value.
     if fail, it returns -1.     
    */

    int sum = 0;

    //If d or fp is NULL, it should return -1.
    if (d == NULL || fp == NULL)
        return -1;

    //calculate sum of the numbers 
    //returned by fp by calling fp for each user item. 
    for (int i = 0; i < d->numItems; i++) {
        sum += fp(d->pArray[i].id, d->pArray[i].name,
            d->pArray[i].purchase);
    }
    return sum;
}