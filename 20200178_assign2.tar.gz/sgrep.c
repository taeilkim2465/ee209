#include <stdio.h>
#include <stdlib.h>
#include <string.h> /* for skeleton code */
#include <unistd.h> /* for getopt */
#include "str.h"

#define FIND_STR        "-f"
#define REPLACE_STR     "-r"
#define DIFF_STR        "-d"

#define MAX_STR_LEN 1023

#define FALSE 0
#define TRUE  1

typedef enum {
  INVALID,
  FIND,
  REPLACE,
  DIFF
} CommandType;

/*
 * Fill out your functions here (If you need) 
 */
/*--------------------------------------------------------------------*/
/* PrintUsage()
   print out the usage of the Simple Grep Program                     */
/*--------------------------------------------------------------------*/
void 
PrintUsage(const char* argv0) 
{
  const static char *fmt = 
    "Simple Grep (sgrep) Usage:\n"
    "%s [COMMAND] [OPTIONS]...\n"
    "\nCOMMNAD\n"
    "\tFind: -f [search-string]\n"
    "\tReplace: -r [string1] [string2]\n"
    "\tDiff: -d [file1] [file2]\n";

  printf(fmt, argv0);
}
/*-------------------------------------------------------------------*/
/* DoFind()
   Your task:
   1. Do argument validation 
   - String or file argument length is no more than 1023
   - If you encounter a command-line argument that's too long, 
   print out "Error: argument is too long"
   
   2. Read the each line from standard input (stdin)
   - If you encounter a line larger than 1023 bytes, 
   print out "Error: input line is too long" 
   - Error message should be printed out to standard error (stderr)
   
   3. Check & print out the line contains a given string (search-string)
      
   Tips:
   - fgets() is an useful function to read characters from file. Note 
   that the fget() reads until newline or the end-of-file is reached. 
   - fprintf(sderr, ...) should be useful for printing out error
   message to standard error

   NOTE: If there is any problem, return FALSE; if not, return TRUE  */
/*-------------------------------------------------------------------*/
int
DoFind(const char *pcSearch)
{
    char buf[MAX_STR_LEN + 2]; 
    int len;
  /* 
   *  Fill out your variables here 
   */

  /* Read the line by line from stdin, Note that this is an example */
    /*check whether the string pcSearch is larger than 1023*/
    if (StrGetLength(pcSearch) > 1023) fprintf(stderr, "Error: argument is too long"); //string length is not larger than 1023
    while (fgets(buf, sizeof(buf), stdin)) {
    /* check input line length */
        if ((len = StrGetLength(buf)) > MAX_STR_LEN) {
            fprintf(stderr, "Error: input line is too long\n");
            return FALSE;
        }
        /*check whether pCSearch is contained in one line*/
        if(StrSearch(buf, pcSearch) != NULL) printf("%s", buf);
    }
    return TRUE;
}
/*-------------------------------------------------------------------*/
/* DoReplace()
   Your task:
   1. Do argument validation 
      - String length is no more than 1023
      - If you encounter a command-line argument that's too long, 
        print out "Error: argument is too long"
      - If word1 is an empty string,
        print out "Error: Can't replace an empty substring"
      
   2. Read the each line from standard input (stdin)
      - If you encounter a line larger than 1023 bytes, 
        print out "Error: input line is too long" 
      - Error message should be printed out to standard error (stderr)

   3. Replace the string and print out the replaced string

   NOTE: If there is any problem, return FALSE; if not, return TRUE  */
/*-------------------------------------------------------------------*/
int
DoReplace(const char *pcString1, const char *pcString2)
{
  /* TODO: fill out this function */ 
    char buf[MAX_STR_LEN + 2];
    int len;
    int len1 = StrGetLength(pcString1);
    int len2 = StrGetLength(pcString2);
    int i;
    int j;
    int count = 0;
    char* result;
    char* ptr_b;

    /*check whether the length of pcString1 and pcString2 is larger than 1023*/
    if (StrGetLength(pcString1) > 1023 || StrGetLength(pcString2) > 1023)
        fprintf(stderr, "Error: argument is too long");
    while (fgets(buf, sizeof(buf), stdin)) {
        /* check input line length */
        if ((len = StrGetLength(buf)) > MAX_STR_LEN) {
            fprintf(stderr, "Error: input line is too long\n");
            return FALSE;
        }
        /*check how many pcString1 is contained in one line*/
        for (i = 0; buf[i] != '\0'; i++) {
            if (StrSearch(&buf[i], pcString1) == &buf[i]) {
                count++;
                i += len1 - 1;
            }
        }
        /*allocate memomry size which is fit to the case when replaced word are put*/
        result = (char*)malloc((i + 1 + (len2 - len1)*count)*sizeof(char));
        
        ptr_b = (char*)buf;
        j = 0;
        while (*ptr_b) {
            /*if pcString1 is found, replace it with pcString2. control the place where the information is saved*/
            if (StrSearch(ptr_b, pcString1) == ptr_b) {
                StrCopy(&result[j], pcString2);
                ptr_b += len1;
                j += len2;
            }
            /*if pcString1 is not found, just copy the line from the original buffer*/
            else {
                result[j] = *ptr_b;
                ptr_b++;
                j++;
            }
        }
        printf("%s", result);
    }
    return TRUE;
}
/*-------------------------------------------------------------------*/
/* DoDiff()
   Your task:
   1. Do argument validation 
     - file name length is no more than 1023
     - If a command-line argument is too long, 
       print out "Error: argument is too long" to stderr

   2. Open the two files
      - The name of files are given by two parameters
      - If you fail to open either file, print out error messsage
      - Error message: "Error: failed to open file [filename]\n"
      - Error message should be printed out to stderr

   3. Read the each line from each file
      - If you encounter a line larger than 1023 bytes, 
        print out "Error: input line [filename] is too long" 
      - Error message should be printed out to stderr

   4. Compare the two files (file1, file2) line by line 

   5. Print out any different line with the following format
      file1@linenumber:file1's line
      file2@linenumber:file2's line

   6. If one of the files ends earlier than the other, print out an
      error message "Error: [filename] ends early at line XX", where
      XX is the final line number of [filename].

   NOTE: If there is any problem, return FALSE; if not, return TRUE  */
/*-------------------------------------------------------------------*/
int
DoDiff(const char *file1, const char *file2)
{
  
  /* TODO: fill out this function */
    char buf1[MAX_STR_LEN + 2];
    char buf2[MAX_STR_LEN + 2];
    char* p1;
    char* p2;
    int len1;
    int len2;
    int line1 = 0;
    int line2 = 0;
    int diff; 
    FILE* f1 = fopen(file1, "r");
    FILE* f2 = fopen(file2, "r");
    /*check whether the file is well opened*/
    if (f1 == NULL) {
        fprintf(stderr, "Error: failed to open %s\n", file1);
        return FALSE;
    }
    if (f2 == NULL) {
        fprintf(stderr, "Error: failed to open %s\n", file2);
        return FALSE;
    }
    /*check whether the file name is larger than 1023*/
    if (StrGetLength(file1) > 1023 || StrGetLength(file2) > 1023)
        fprintf(stderr, "Error: argument is too long");

    while ((p1 = fgets(buf1, sizeof(buf1), f1)) && (p2 = fgets(buf2, sizeof(buf2), f2))) {
        /* check input line length */
        if ((len1 = StrGetLength(buf1)) > MAX_STR_LEN || (len2 = StrGetLength(buf1)) > MAX_STR_LEN) {
            fprintf(stderr, "Error: input line is too long\n");
            return FALSE;
        }
        /*initiate the value of diff to 0(false)*/
        diff = 0;
        /*if any character in two lines are different, then change th value of diff to 1(true)*/
        for (int i = 0; buf1[i] != '\0'; i++) {
            if (buf1[i] != buf2[i]) {
                diff = 1;
                break;
            }
            continue;
        }
        if (diff) printf("%s@%d:%s%s@%d:%s", file1, line1 + 1, buf1, file2, line2 + 1, buf2);
        line1++;
        line2++;
    }

    if (p1 == NULL && p2 != NULL) {
        /*if p1 is NULL(former one is true), 'while' condition statement doesn't check the latter one. so, if in this case first read a line from f2 */
        p2 = fgets(buf2, sizeof(buf2), f2);
        line2++;
        if (p1 == NULL && p2 != NULL) {
            fprintf(stderr, "Error: %s ends early at line %d", file1, line1);
            return FALSE;
        }
    }
    else if (p1 != NULL && p2 == NULL) {
        fprintf(stderr, "Error: %s ends early at line %d", file2, line2);
        return FALSE;
    }
    return TRUE;
}
/*-------------------------------------------------------------------*/
/* CommandCheck() 
   - Parse the command and check number of argument. 
   - It returns the command type number
   - This function only checks number of argument. 
   - If the unknown function is given or the number of argument is 
   different from required number, this function returns FALSE.
   
   Note: You SHOULD check the argument rule later                    */
/*-------------------------------------------------------------------*/ 
int
CommandCheck(const int argc, const char *argv1)
{
  int cmdtype = INVALID;
   
  /* check minimum number of argument */
  if (argc < 3)
    return cmdtype;
   
  /* check command type */ 
  if (strcmp(argv1, FIND_STR) == 0) {
    if (argc != 3)
      return FALSE;    
    cmdtype = FIND;       
  }
  else if (strcmp(argv1, REPLACE_STR) == 0) {
    if (argc != 4)
      return FALSE;
    cmdtype = REPLACE;
  }
  else if (strcmp(argv1, DIFF_STR) == 0) {
    if (argc != 4)
      return FALSE;
    cmdtype = DIFF;
  }
   
  return cmdtype;
}
/*-------------------------------------------------------------------*/
int 
main(const int argc, const char *argv[]) 
{
  int type, ret;
   
  /* Do argument check and parsing */
  if (!(type = CommandCheck(argc, argv[1]))) {
    fprintf(stderr, "Error: argument parsing error\n");
    PrintUsage(argv[0]);
    return (EXIT_FAILURE);
  }
   
  /* Do appropriate job */
  switch (type) {
  case FIND:
    ret = DoFind(argv[2]);
    break;
  case REPLACE:
    ret = DoReplace(argv[2], argv[3]);
    break;
  case DIFF:
    ret = DoDiff(argv[2], argv[3]);
    break;
  } 

  return (ret)? EXIT_SUCCESS : EXIT_FAILURE;
}