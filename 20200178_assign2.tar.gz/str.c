#include <assert.h> /* to use assert() */
#include <stdio.h>
#include "str.h"

/* Your task is:
   1. Rewrite the body of "Part 1" functions - remove the current
      body that simply calls the corresponding C standard library
      function.
   2. Write appropriate comment per each function
*/

/* Part 1 */
/*------------------------------------------------------------------------*/
size_t StrGetLength(const char* pcSrc){
    const char* pcEnd;
    assert(pcSrc); /* NULL address, 0, and FALSE are identical. */
    pcEnd = pcSrc;

    while (*pcEnd) /* null character and FALSE are identical. */
        pcEnd++;

    return (size_t)(pcEnd - pcSrc);
}

/*------------------------------------------------------------------------*/
char* StrCopy(char* pcDest, const char* pcSrc)
{
    /* TODO: fill this function */
    char* ptr_pcDest = pcDest;
    assert(pcDest);
    assert(pcSrc);

    while (*pcSrc) {
        *ptr_pcDest = *pcSrc; //put the value which pcSrc reference to the value which pcDest reference
        ptr_pcDest++;
        pcSrc++;
    }
    *ptr_pcDest = 0; //add null pointer at the end of string
    return pcDest;
}

/*------------------------------------------------------------------------*/
int StrCompare(const char* pcS1, const char* pcS2)
{
    /* TODO: fill this function */
    int strlen1 = StrGetLength(pcS1);
    int strlen2 = StrGetLength(pcS2);
    const char* ptr_pcS1 = pcS1;
    const char* ptr_pcS2 = pcS2;
    assert(pcS1);
    assert(pcS2);
    /*pcS1�� pcS2���� ���������� �տ� ������ -1, �ڿ� ������ 1, ������ 0*/
    while (*ptr_pcS1 && *ptr_pcS2) {
        if (*ptr_pcS1 > * ptr_pcS2) {
            return 1;
        }
        else if (*ptr_pcS1 < *ptr_pcS2) {
            return -1;
        }
        ptr_pcS1++;
        ptr_pcS2++;
    }
    if (strlen1 > strlen2) return 1;
    else if (strlen1 < strlen2) return -1;
    return 0;
}
/*------------------------------------------------------------------------*/
char* StrSearch(const char* pcHaystack, const char* pcNeedle)
{
    /* TODO: fill this function */
    char* ptr_H;
    char* ptr_N;
    char* ptr_pcHaystack = (char*)pcHaystack;
    char* ptr_pcNeedle = (char*)pcNeedle;
    assert(pcHaystack);
    assert(pcNeedle);
 
    if (*pcNeedle == 0) return (char*)pcHaystack;
    while (*ptr_pcHaystack) {
        ptr_H = ptr_pcHaystack;
        ptr_N = ptr_pcNeedle;
        /*if a character in pcHaystack is same as the first character of pcNeedle, until end of pcNeedle compare two characters are the same*/
        while (*ptr_H && *ptr_N && (*ptr_H == *ptr_N)) {
            ptr_H++;
            ptr_N++;
        }
        if (*ptr_N == 0) return ptr_pcHaystack;
        ptr_pcHaystack++;
    }
    return NULL;
}
/*------------------------------------------------------------------------*/
char* StrConcat(char* pcDest, const char* pcSrc)
{
    /* TODO: fill this function */
    int pcSrcLen = StrGetLength(pcSrc);
    char* ptr_pcDest = pcDest;
    const char* ptr_pcSrc = pcSrc;
    assert(pcDest);
    assert(pcSrc);

    while (*ptr_pcDest) {
        ptr_pcDest++;
    }
    /*from the end of pcDest(null pointer) copy value of pcSrc until the string meets null pointer*/
    for (int i = 0; i < pcSrcLen + 1; i++) {
        *ptr_pcDest = *ptr_pcSrc;
        ptr_pcDest++;
        ptr_pcSrc++;
    }
    return pcDest;
}