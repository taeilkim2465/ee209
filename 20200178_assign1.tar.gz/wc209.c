#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int main(void) {
	int c;
	int nLine = 0;
	int nWord = 0;
	int nChar = 0;
	int state = 1;
	int stateComment = 1;
	int star = 1;
	int slash = 1;
	int count = 0;
	int lineCount = 0;

	while ((c = getchar()) != EOF) {
		if (count == 0) nLine++;

		if (c == '\n') nLine++;

		switch (stateComment) {
		case 0://주석 안쪽
			if (c == '\n') {
				nChar++;
			}
			else if (c == '*') {
				while (star--) {
					char nextC = getchar();
					if (nextC == '/') {
						stateComment = 1;
						state = 1;
					}
					else if (nextC == '\n') {
						nChar++;
						nLine++;
					}
					else if (nextC == '*') {
						star = 1;
					}
				}
				star = 1;
			}
			break;

		case 1://주석 바깥쪽
			switch (state) {
			case 0://단어 안쪽
				if (isspace(c)) {
					state = 1;
				}
				else if (c == '/') {
					while (slash--) {
						char nextC = getchar();
						if (nextC == '*') {
							stateComment = 0;
							lineCount = nLine;
						}
						else if (nextC == '/') {
							state = 0;
							nChar++;
							slash = 1;
						}
						else if (nextC == '\n') {
							state = 1;
							nChar++;
							nLine++;
						}
						else if (isspace(nextC)) {
							state = 1;
							nChar++;
						}
						else {
							state = 0;
							nChar++;
						}
					}
					slash = 1;
				}
				nChar++;
				break;
			case 1://단어 바깥쪽
				if (!isspace(c)) {
					state = 0;
					if (c == '/') {
						while (slash--) {
							char nextC = getchar();
							if (nextC == '*') {
								stateComment = 0;
								lineCount = nLine;
							}
							else if (nextC == '/') {
								nWord++;
								nChar++;
								slash = 1;
							}
							else if (nextC == '\n') {
								state = 1;
								nWord++;
								nChar++;
								nLine++;
							}
							else if (isspace(nextC)) {
								state = 1;
								nWord++;
								nChar++;
							}
							else {
								nWord++;
								nChar++;
							}
						}
						slash = 1;
					}
					else {
						nWord++;
					}
				}
				nChar++;
				break;
			}
			break;
		}
		count++;
	}
	if (stateComment == 0) {
		fprintf(stderr, "Error: line %d: unterminated comment\n", lineCount);
		return EXIT_FAILURE;
	}
	else {
		printf("%d %d %d\n", nLine, nWord, nChar);
		return EXIT_SUCCESS;
	}
}